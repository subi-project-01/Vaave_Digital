# HARSHU Academy

A responsive course-platform website built with React, HTML and CSS.

## Features
- Four navigable sections: Home, About, Courses and Contact
- Responsive navigation menu for mobile
- Course search and category filters
- Course detail pop-up with expanded overview, topics, skills, duration and learning outcomes
- Contact form with optional fields that opens WhatsApp with a pre-filled enquiry
- No popup notification or compulsory form validation

## Run locally
1. Install Node.js (LTS recommended).
2. Open this project folder in VS Code.
3. Open the terminal in the project folder and run:

   ```bash
   npm install
   npm run dev
   ```

4. Open the local URL shown by Vite (usually http://localhost:5173).

## Important
The contact form opens WhatsApp with the enquiry details pre-filled. Visitors must press **Send** in WhatsApp to submit the enquiry.

Before publishing, update the `whatsappNumber` value in `src/main.jsx` to your WhatsApp number in international format (country code and digits only, without `+` or spaces). The displayed email and phone number are sample details; replace them with your actual contact information.
